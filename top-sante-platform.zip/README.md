# Top Santé : Santé et éducation
Plateforme de cours en ligne sur la santé, en formats PDF et vidéo. Accessible sur abonnement. Langues : français et bambara.
